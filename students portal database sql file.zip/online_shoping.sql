-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 06, 2021 at 01:33 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_shoping`
--

-- --------------------------------------------------------

--
-- Table structure for table `connect`
--

CREATE TABLE `connect` (
  `id` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `names` varchar(100) NOT NULL,
  `relationship` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `school` varchar(25) NOT NULL,
  `location` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `photo` blob NOT NULL,
  `photo1` blob NOT NULL,
  `photo2` blob NOT NULL,
  `date_post` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `connect`
--

INSERT INTO `connect` (`id`, `postid`, `names`, `relationship`, `phone`, `school`, `location`, `description`, `photo`, `photo1`, `photo2`, `date_post`, `status`) VALUES
(1, 697653, 'peter adewale', 'friendship', '08033223344', 'unilag', 'lagos', 'I\'m a good looking guy and i\'m tall and handsome', 0x3639373635332e6a7067, '', '', '2021-06-21 13:12:38', 1),
(2, 389687, 'Lil fresh', 'relationship', '09145362854', 'kwasu', 'kwara state', 'I\'m way too big', 0x3338393638372e6a7067, '', '', '2021-06-21 13:12:48', 1);

-- --------------------------------------------------------

--
-- Table structure for table `post_ads`
--

CREATE TABLE `post_ads` (
  `id` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `names` varchar(100) NOT NULL,
  `price` double NOT NULL,
  `phone` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `photo` blob NOT NULL,
  `photo1` blob NOT NULL,
  `photo2` blob NOT NULL,
  `date_post` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post_ads`
--

INSERT INTO `post_ads` (`id`, `postid`, `names`, `price`, `phone`, `description`, `photo`, `photo1`, `photo2`, `date_post`, `status`) VALUES
(1, 832254, 'Gift Cards', 42000, '4543534545', 'dfgerterter', 0x3833323235342e6a7067, '', '', '2021-06-19 16:04:05', 1),
(4, 346824, 'Fresh barbing', 55000, '0903435362224', 'My concept is very legit and this is why i\'m the best in what i do. Note this is just a dummy text, i am so freaking good at\r\nmy job', 0x3334363832342e6a7067, '', '', '2021-06-21 01:51:30', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sellings`
--

CREATE TABLE `sellings` (
  `id` int(11) NOT NULL,
  `postid` varchar(10) NOT NULL,
  `names` varchar(150) NOT NULL,
  `price` double NOT NULL,
  `phone` varchar(20) NOT NULL,
  `school` varchar(150) NOT NULL,
  `location` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `photo` blob NOT NULL,
  `date_post` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sellings`
--

INSERT INTO `sellings` (`id`, `postid`, `names`, `price`, `phone`, `school`, `location`, `description`, `photo`, `date_post`, `status`) VALUES
(1, '422966', 'werwerwer', 324234, '08066554432', 'Ladoke Akintola University', 'Ogbomosho', 'sfgwrewtewte', 0x3432323936362e6a7067, '2021-06-19 15:00:22', 1),
(2, '354345', 'Cooking Gas Cylinder', 12000, '08033223344', 'The Federal Polytechnic Ede', 'Osun', 'A well used cooking of 5kg.', 0x3335343334352e6a7067, '2021-06-14 16:34:38', 1),
(3, '599267', 'Laptop Screen', 25000, '98763456536453', 'ABU, Zaria', 'Zaria Kaduna', 'A follow come hp laptop screen, no scrash', 0x3539393236372e6a7067, '2021-06-19 15:08:24', 1),
(4, '985893', 'Phone Charger', 1500, '879364234', 'Union Osun', 'Osogbo', 'Very durable and last long', 0x3938353839332e6a7067, '2021-06-19 14:44:33', 2);

-- --------------------------------------------------------

--
-- Table structure for table `shoping_admin`
--

CREATE TABLE `shoping_admin` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pin` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shoping_admin`
--

INSERT INTO `shoping_admin` (`id`, `name`, `username`, `password`, `role`, `email`, `pin`) VALUES
(6, 'Taiwo Sarafa Aderemi', 'aderemi641', '$2y$10$mL8fsypLR/esIwIOQyVBBurk/YkJ1rjbUl4ZsbFvVgO2AFm73AUTm', 'admin', 'aderemi.s641@gmail.com', 1),
(9, 'olah', 'jon', '$2y$10$hwd84K.KivkWLFaaR5WOjeIkq9J1pzVFlzjnt80JLZZjxRnM2KHku', 'admin', 'olahisrael07@gmail.com', 0);

-- --------------------------------------------------------

--
-- Table structure for table `shoping_users`
--

CREATE TABLE `shoping_users` (
  `id` int(11) NOT NULL,
  `userid` varchar(10) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `school` varchar(200) NOT NULL,
  `state` varchar(20) NOT NULL,
  `phone` varchar(18) NOT NULL,
  `gender` char(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date_register` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shoping_users`
--

INSERT INTO `shoping_users` (`id`, `userid`, `full_name`, `school`, `state`, `phone`, `gender`, `email`, `password`, `date_register`) VALUES
(1, '39636', 'New User', 'FPE', 'Osun', '', 'Male', 'newuser@gmail.com', '$2y$10$aDIhd5ckUis.hsmknrylCe5TbSKpgiUU7vyaXf9pumOWBT10JbWr2', '2021-06-14 15:44:38'),
(2, '23129', 'New User', 'FPE', 'Osun', '', 'Male', 'newuser@gmail.com', '$2y$10$wFkdbTrQwtipX47ZHQwGreGbG0/QipipFslLN3TMuY2jG3oAkHtU6', '2021-06-08 11:03:51'),
(3, '63000', 'Another User', 'OAU', 'Osun', '', 'Female', 'anotheruser@gmail.com', '$2y$10$7Rc.9hBpxtjfpoh2cnuoF.jxDycrhPMgyWA4T4ZxbGG8V3qKZYI2m', '2021-06-08 11:05:35'),
(4, '39636', 'FPE Member', 'Obafemi Awolowo University', 'Ife, Osun State', '08066554423', 'Female', 'fpemember@gmail.com', '$2y$10$gqte./nPOqbzoCmYxdVGKOGHZI7U77h3e9FQD33uxXbLwO4doH3my', '2021-06-09 16:23:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `connect`
--
ALTER TABLE `connect`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post_ads`
--
ALTER TABLE `post_ads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sellings`
--
ALTER TABLE `sellings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shoping_admin`
--
ALTER TABLE `shoping_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shoping_users`
--
ALTER TABLE `shoping_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `connect`
--
ALTER TABLE `connect`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `post_ads`
--
ALTER TABLE `post_ads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sellings`
--
ALTER TABLE `sellings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `shoping_admin`
--
ALTER TABLE `shoping_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `shoping_users`
--
ALTER TABLE `shoping_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
